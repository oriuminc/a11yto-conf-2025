/* Accessibility-first interactions for AETOS */
(function () {
  const qs = (s, r = document) => r.querySelector(s);
  const qsa = (s, r = document) => Array.from(r.querySelectorAll(s));

  // Utils
  const trapFocus = (container, onEscape) => {
    const focusable = () => qsa(
      'a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])',
      container
    ).filter(el => el.offsetParent !== null || container === el);
    const first = () => focusable()[0];
    const last = () => focusable()[focusable().length - 1];

    const onKey = (e) => {
      if (e.key === 'Escape') { onEscape?.(e); }
      if (e.key !== 'Tab') return;
      const f = focusable();
      if (!f.length) return;
      if (e.shiftKey && document.activeElement === first()) { e.preventDefault(); last().focus(); }
      else if (!e.shiftKey && document.activeElement === last()) { e.preventDefault(); first().focus(); }
    };
    container.addEventListener('keydown', onKey);
    return () => container.removeEventListener('keydown', onKey);
  };

  const liveAnnounce = (el, msg) => { if (el) { el.textContent = ''; setTimeout(() => el.textContent = msg, 10); } };

  // Welcome Dialog
  const dialog = qs('#welcome-dialog');
  const dialogErrors = qs('#welcome-errors');
  let releaseTrap = null;
  const openDialog = () => {
    dialog.hidden = false;
    releaseTrap = trapFocus(dialog, closeDialog);
    const first = qs('input, button', dialog);
    first?.focus();
  };
  const closeDialog = () => {
    dialog.hidden = true;
    releaseTrap?.();
  };
  // Open after delay for demo; ensure accessibility with focus
  window.setTimeout(openDialog, 600);
  qsa('[data-close="dialog"]').forEach(b => b.addEventListener('click', closeDialog));

  qs('#welcome-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = qs('#welcome-name');
    const email = qs('#welcome-email');
    const errs = [];
    if (!name.value.trim()) errs.push('Please enter your name.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) errs.push('Enter a valid email address.');
    dialogErrors.innerHTML = errs.map(m => `<div>${m}</div>`).join('');
    if (!errs.length) {
      dialogErrors.textContent = 'Thanks for joining!';
      closeDialog();
    }
  });

  // Header: Mega menu (desktop)
  const menubar = qs('#menubar');
  if (menubar) {
    const items = qsa(':scope > li', menubar);
    const topButtons = qsa(':scope > li > .menubar__btn, :scope > li > .menubar__link', menubar);

    const setExpanded = (btn, expanded) => {
      if (!btn || !btn.matches('.menubar__btn')) return;
      btn.setAttribute('aria-expanded', String(expanded));
      const parent = btn.closest('li');
      if (parent) parent.setAttribute('aria-expanded', String(expanded));
    };
    const closeAll = () => {
      qsa('.menubar__btn[aria-expanded="true"]', menubar).forEach(b => setExpanded(b, false));
    };

    menubar.addEventListener('keydown', (e) => {
      const currentIndex = topButtons.indexOf(document.activeElement);
      if (e.key === 'ArrowRight') { e.preventDefault(); topButtons[(currentIndex + 1) % topButtons.length]?.focus(); }
      if (e.key === 'ArrowLeft') { e.preventDefault(); topButtons[(currentIndex - 1 + topButtons.length) % topButtons.length]?.focus(); }
      if (e.key === 'Escape') { closeAll(); topButtons[currentIndex]?.focus(); }
      if ((e.key === 'Enter' || e.key === ' ') && document.activeElement?.matches('.menubar__btn')) {
        e.preventDefault();
        const btn = document.activeElement;
        const expanded = btn.getAttribute('aria-expanded') === 'true';
        setExpanded(btn, !expanded);
        if (!expanded) {
          const firstLink = btn.nextElementSibling?.querySelector('a, button');
          firstLink?.focus();
        }
      }
      if (e.key === 'ArrowDown' && document.activeElement?.matches('.menubar__btn')) {
        e.preventDefault();
        const btn = document.activeElement;
        setExpanded(btn, true);
        const firstLink = btn.nextElementSibling?.querySelector('a, button');
        firstLink?.focus();
      }
    });

    document.addEventListener('click', (e) => {
      if (!menubar.contains(e.target)) closeAll();
    });
  }

  // Mobile menu
  const mobile = qs('#mobile-menu');
  const hamb = qs('#hamburger');
  let releaseMobileTrap = null;
  const openMobile = () => {
    mobile.hidden = false;
    hamb.setAttribute('aria-expanded', 'true');
    releaseMobileTrap = trapFocus(mobile, closeMobile);
    qs('.mobile-menu__close', mobile)?.focus();
  };
  const closeMobile = () => {
    mobile.hidden = true;
    hamb.setAttribute('aria-expanded', 'false');
    releaseMobileTrap?.();
    hamb.focus();
  };
  hamb?.addEventListener('click', openMobile);
  qsa('[data-close="mobile"]').forEach(b => b.addEventListener('click', closeMobile));
  mobile?.addEventListener('click', (e) => { if (e.target.classList.contains('mobile-menu__backdrop')) closeMobile(); });
  qsa('.mobile-expander').forEach(btn => btn.addEventListener('click', () => {
    const expanded = btn.getAttribute('aria-expanded') === 'true';
    btn.setAttribute('aria-expanded', String(!expanded));
    const panel = qs('#' + btn.getAttribute('aria-controls'));
    if (panel) panel.hidden = expanded;
  }));

  // Predictive Search (ARIA combobox)
  const searchInput = qs('#search-input');
  const listbox = qs('#search-listbox');
  const status = qs('#search-status');
  const sample = [
    'Aetos Pro Automatic', 'Heritage 38 Quartz', 'Carbon Pilot Chrono', 'Marine Diver 200',
    'Dress Watch Leather', 'Diver Ceramic Bezel', 'Pilot GMT', 'Chronograph Steel'
  ];
  let activeIndex = -1;
  const updateList = (q) => {
    const results = sample.filter(s => s.toLowerCase().includes(q.toLowerCase())).slice(0, 8);
    listbox.innerHTML = results.map((r, i) => `<li id="opt-${i}" role="option" aria-selected="${i===activeIndex}">${r}</li>`).join('');
    if (q && results.length) {
      listbox.classList.add('show');
      listbox.setAttribute('aria-expanded', 'true');
      searchInput.setAttribute('aria-expanded', 'true');
    } else {
      listbox.classList.remove('show');
      listbox.setAttribute('aria-expanded', 'false');
      searchInput.setAttribute('aria-expanded', 'false');
    }
    liveAnnounce(status, results.length ? `${results.length} results` : 'No results');
  };
  searchInput?.addEventListener('input', (e) => { activeIndex = -1; searchInput.removeAttribute('aria-activedescendant'); updateList(e.target.value); });
  searchInput?.addEventListener('keydown', (e) => {
    const options = qsa('[role="option"]', listbox);
    if (e.key === 'ArrowDown') { e.preventDefault(); activeIndex = Math.min(activeIndex + 1, options.length - 1); }
    if (e.key === 'ArrowUp') { e.preventDefault(); activeIndex = Math.max(activeIndex - 1, 0); }
    if (e.key === 'Enter' && activeIndex >= 0) { e.preventDefault(); searchInput.value = options[activeIndex].textContent; updateList(searchInput.value); listbox.classList.remove('show'); }
    options.forEach((o, i) => { o.setAttribute('aria-selected', String(i === activeIndex)); if (i === activeIndex) { searchInput.setAttribute('aria-activedescendant', o.id); o.scrollIntoView({ block: 'nearest' }); } });
  });
  listbox?.addEventListener('click', (e) => {
    const li = e.target.closest('[role="option"]');
    if (!li) return;
    searchInput.value = li.textContent;
    updateList(searchInput.value);
    listbox.classList.remove('show');
  });

  // Carousels
  const makeCarousel = (name) => {
    const root = qs(`.carousel[data-carousel="${name}"]`);
    if (!root) return;
    const track = qs('.carousel__track', root);
    const items = qsa(':scope > *', track);
    let index = 0; let timer = null; let paused = false;
    const status = qs(`#${name}-status`);

    const setIndex = (i, announce = true) => {
      index = (i + items.length) % items.length;
      const cardWidth = items[0].getBoundingClientRect().width + parseFloat(getComputedStyle(track).gap || 0);
      track.style.transform = `translateX(${index * -cardWidth}px)`;
      if (announce) liveAnnounce(status, `Showing item ${index + 1} of ${items.length}`);
    };

    const next = () => setIndex(index + 1);
    const prev = () => setIndex(index - 1);

    const start = () => { timer = window.setInterval(() => { if (!paused) next(); }, 4000); };
    const stop = () => { window.clearInterval(timer); timer = null; };

    qsa(`[data-carousel="${name}"][data-action="next"]`).forEach(btn => btn.addEventListener('click', next));
    qsa(`[data-carousel="${name}"][data-action="prev"]`).forEach(btn => btn.addEventListener('click', prev));
    qsa(`[data-carousel="${name}"][data-action="pause"]`).forEach(btn => btn.addEventListener('click', () => {
      paused = !paused; btn.setAttribute('aria-pressed', String(paused)); btn.textContent = paused ? 'Play' : 'Pause';
    }));

    root.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowRight') { e.preventDefault(); next(); }
      if (e.key === 'ArrowLeft') { e.preventDefault(); prev(); }
    });

    setIndex(0, false); start();
  };
  makeCarousel('categories');
  makeCarousel('products');

  // Newsletter form
  const newsForm = qs('#newsletter');
  const newsErrors = qs('#news-errors');
  newsForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = qs('#news-email');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
      newsErrors.textContent = 'Enter a valid email address.';
      return;
    }
    newsErrors.textContent = 'Thanks for subscribing!';
  });

  // Year in footer
  const year = qs('#year'); if (year) year.textContent = String(new Date().getFullYear());
})();
