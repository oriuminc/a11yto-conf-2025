'use strict';

// Data
const CATEGORIES = [
  { name: 'The Vanguard Chronograph', href: '#vanguard', image: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?q=80&w=1200&auto=format&fit=crop' },
  { name: 'The Sentinel Automatic', href: '#sentinel', image: 'https://images.unsplash.com/photo-1468245856972-a0333f3f8293?q=80&w=1200&auto=format&fit=crop' },
  { name: 'The Shoreline Diver', href: '#shoreline', image: 'https://images.unsplash.com/photo-1506197603052-3cc9c3a201bd?q=80&w=1200&auto=format&fit=crop' },
  { name: 'Premium Leather Straps', href: '#leather-straps', image: 'https://images.unsplash.com/photo-1590154917861-6d4b6f4a4560?q=80&w=1200&auto=format&fit=crop' },
  { name: 'Travel & Storage', href: '#travel-storage', image: 'https://images.unsplash.com/photo-1556228578-0be3481b3319?q=80&w=1200&auto=format&fit=crop' }
];

const PRODUCTS = [
  ['Vanguard Chrono - Midnight','Vanguard Chronograph',425,'A classic panda dial with deep black subdials and a polished steel case.'],
  ['Vanguard Chrono - Sterling','Vanguard Chronograph',425,'A sunburst silver dial that captures the light, paired with a brown leather strap.'],
  ['Vanguard Chrono - Navy Gold','Vanguard Chronograph',450,'A striking deep navy dial with gold-tone hands and indices.'],
  ['Sentinel 40 - Classic White','Sentinel Automatic',550,'An elegant automatic with a clean white dial and a 40-hour power reserve.'],
  ['Sentinel 40 - Onyx','Sentinel Automatic',550,'A versatile black dial automatic, perfect for both formal and casual wear.'],
  ['Sentinel 38 - Exhibition','Sentinel Automatic',575,'A slightly smaller case with a stunning exhibition back showing the Miyota movement.'],
  ['Shoreline Diver - Abyss','Shoreline Diver',495,'A 200M water-resistant diver with a ceramic bezel and luminous markers.'],
  ['Shoreline Diver - Tropic','Shoreline Diver',495,'A vintage-inspired diver with a teal dial and a stainless steel bracelet.'],
  ['The Minimalist 36 - Pearl','Minimalist 36',295,'A refined 36mm quartz watch with a mother-of-pearl dial.'],
  ['The Minimalist 36 - Slate','Minimalist 36',295,'A modern, unisex design with a matte grey dial and no indices.'],
  ['Italian Leather Strap - Oak','Leather Straps',75,'A rich brown, full-grain leather strap that develops a beautiful patina.'],
  ['Italian Leather Strap - Black','Leather Straps',75,'A classic black leather strap with contrast white stitching.'],
  ['Steel Bracelet - Brushed','Steel Bracelets',110,'A 316L stainless steel oyster-style bracelet with a brushed finish.'],
  ['Steel Bracelet - Polished','Steel Bracelets',110,'A five-link polished steel bracelet for a more refined, dressy look.'],
  ['Nylon Strap - Forest Green','Nylon Straps',45,'A durable, single-pass nylon strap perfect for outdoor use.'],
  ['Nylon Strap - Khaki','Nylon Straps',45,'A versatile and military-inspired khaki nylon strap.'],
  ['Canvas Watch Roll - 3 Slot','Watch Rolls & Cases',95,'A waxed canvas roll with soft lining to protect three watches during travel.'],
  ['Leather Watch Case - Single','Watch Rolls & Cases',120,'A premium black leather hard case for storing a single cherished timepiece.'],
  ['Spring Bar Tool - Pro','Strap Tools',35,'A professional-grade steel tool for easily changing straps.'],
  ['Travel Pouch - Suede','Watch Rolls & Cases',55,'A simple and elegant suede pouch for protecting your watch from scratches.'],
];

const ARTICLES = [
  ['Automatic vs. Quartz: A Guide','Mark Jennings','Aug 12, 2025','Understanding the intricate mechanics of an automatic movement versus the precision of quartz. We break down what makes each one tick.','https://images.unsplash.com/photo-1524805444758-089113d48a6d?q=80&w=1600&auto=format&fit=crop'],
  ['How to Pair Your Watch and Strap','Alisha Khan','Aug 05, 2025','A complete style guide to matching your timepiece with the perfect strap for any occasion, from the boardroom to the beach.','https://images.unsplash.com/photo-1504051771394-dd2e66b2e08f?q=80&w=1600&auto=format&fit=crop'],
  ['The Enduring Appeal of the Dive Watch','Mark Jennings','Jul 28, 2025','From military history to modern icon, we explore why the dive watch remains one of the most popular styles in the world.','https://images.unsplash.com/photo-1547996160-81dfa63595aa?q=80&w=1600&auto=format&fit=crop'],
  ['A Look Inside Our Workshop','David Chen','Jul 21, 2025','Go behind the scenes at AETOS and meet the people who design, assemble, and test every timepiece we create.','https://images.unsplash.com/photo-1533104816931-20fa691ff6ca?q=80&w=1600&auto=format&fit=crop'],
  ['Caring for Your Leather Strap','Alisha Khan','Jul 14, 2025','Simple tips and tricks to clean, condition, and preserve your leather strap, ensuring it ages as gracefully as your watch.','https://images.unsplash.com/photo-1511379938547-c1f69419868d?q=80&w=1600&auto=format&fit=crop'],
  ['What is Sapphire Crystal?','Mark Jennings','Jul 07, 2025','We explain why we use sapphire crystal in all our watches and why it’s the gold standard for scratch resistance and clarity.','https://images.unsplash.com/photo-1496492690973-97e09f0d9f40?q=80&w=1600&auto=format&fit=crop'],
  ['5 Iconic Watches in Cinema','Liam Carter','Jun 30, 2025','From spies to astronauts, a look at the legendary timepieces that have shared the silver screen with Hollywood’s biggest stars.','https://images.unsplash.com/photo-1520401449559-4b52f3214a2d?q=80&w=1600&auto=format&fit=crop'],
  ['The AETOS Design Philosophy','David Chen','Jun 23, 2025','Our founder discusses the principles of minimalism, function, and timelessness that guide every AETOS design.','https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=1600&auto=format&fit=crop'],
  ['A Brief History of the Chronograph','Mark Jennings','Jun 16, 2025','Discover the fascinating history of the chronograph, from its origins in horse racing to its essential role in the space race.','https://images.unsplash.com/photo-1447069387593-a5de0862481e?q=80&w=1600&auto=format&fit=crop'],
  ['Summer Style: The Best Watch Combos','Alisha Khan','Jun 09, 2025','Lighten up your look for the warmer months with our top picks for watch and strap combinations that exude summer style.','https://images.unsplash.com/photo-1519996529931-28324d5a630e?q=80&w=1600&auto=format&fit=crop'],
  ['Why 316L Steel Matters','Mark Jennings','Jun 02, 2025','Not all steel is created equal. Learn why we use surgical-grade 316L stainless steel for its superior corrosion resistance and durability.','https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?q=80&w=1600&auto=format&fit=crop'],
  ["Packing for Travel: The Watch Lover’s Guide",'Liam Carter','May 26, 2025','How to choose which watches to bring on your next trip and the best way to keep them safe and secure on the go.','https://images.unsplash.com/photo-1516382785486-1ab472efccf5?q=80&w=1600&auto=format&fit=crop'],
];

// Utils
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const currency = v => new Intl.NumberFormat('en-CA',{style:'currency',currency:'CAD'}).format(v);

// Sticky header shadow on scroll
const header = $('.header');
const toggleHeaderShadow = () => { header.style.boxShadow = window.scrollY > 4 ? 'var(--shadow-md)' : 'none'; };
window.addEventListener('scroll', toggleHeaderShadow, { passive:true });

toggleHeaderShadow();

// Mobile drawer
const drawer = $('.mobile-drawer');
$('#hamburger').addEventListener('click', () => { drawer.classList.add('open'); $('#hamburger').setAttribute('aria-expanded','true'); $('#drawer-close').focus(); });
$('#drawer-close').addEventListener('click', () => { drawer.classList.remove('open'); $('#hamburger').setAttribute('aria-expanded','false'); });
$$('.mobile-drawer a').forEach(a=> a.addEventListener('click', () => { drawer.classList.remove('open'); $('#hamburger').setAttribute('aria-expanded','false'); }));

// Predictive search (combobox)
(function(){
  const input = $('#search');
  const panel = $('#search-results');
  const list = $('#search-list');
  let items = [];
  let active = -1;

  function build(){
    list.innerHTML = '';
    const q = input.value.trim().toLowerCase();
    const results = [];

    const push = (label, href, meta) => results.push({label, href, meta});

    // Products
    PRODUCTS.filter(([n,c]) => n.toLowerCase().includes(q) || c.toLowerCase().includes(q))
      .slice(0,5).forEach(([n,c,p]) => push(n, '#', currency(p)));

    // Categories
    CATEGORIES.filter(c => c.name.toLowerCase().includes(q)).slice(0,3)
      .forEach(c => push(c.name, c.href, 'Category'));

    // Popular queries
    ['automatic','chronograph','dive','leather strap','steel bracelet'].filter(x => x.includes(q)).slice(0,5)
      .forEach(x => push(`Search “${x}”`, '#', 'Popular'));

    const groups = [
      { title:'Products', items: results.filter(r=>r.meta && r.meta.startsWith('$')) },
      { title:'Categories', items: results.filter(r=>r.meta==='Category') },
      { title:'Popular', items: results.filter(r=>r.meta==='Popular') },
    ];

    items = [];
    groups.forEach(g => {
      if(!g.items.length) return;
      const h = document.createElement('li');
      h.className = 'search-section-title';
      h.textContent = g.title;
      list.appendChild(h);
      g.items.forEach((it, i) => {
        const li = document.createElement('li');
        const btn = document.createElement('button');
        btn.setAttribute('role','option');
        btn.setAttribute('id', `opt-${items.length}`);
        btn.innerHTML = `<span>${it.label}</span><span class="muted small">${it.meta||''}</span>`;
        btn.addEventListener('click', () => { window.location.hash = it.href; hide(); input.value=''; });
        li.appendChild(btn); list.appendChild(li); items.push(btn);
      });
    });

    if(results.length){ show(); } else { hide(); }
  }

  function show(){ panel.hidden = false; input.setAttribute('aria-expanded','true'); }
  function hide(){ panel.hidden = true; input.setAttribute('aria-expanded','false'); input.removeAttribute('aria-activedescendant'); active = -1; items.forEach(x=>x.setAttribute('aria-selected','false')); }

  input.addEventListener('input', build);
  input.addEventListener('focus', () => { if(input.value) build(); });
  input.addEventListener('keydown', (e) => {
    if(panel.hidden) return;
    if(['ArrowDown','ArrowUp'].includes(e.key)){ e.preventDefault(); move(e.key==='ArrowDown'?1:-1); }
    else if(e.key==='Enter' && active>=0){ e.preventDefault(); items[active].click(); }
    else if(e.key==='Escape'){ hide(); }
  });

  function move(dir){
    if(!items.length) return;
    active = (active + dir + items.length) % items.length;
    items.forEach((b,i)=> b.setAttribute('aria-selected', String(i===active)) );
    input.setAttribute('aria-activedescendant', items[active].id);
    items[active].focus();
  }

  document.addEventListener('click', (e)=>{ if(!panel.contains(e.target) && e.target!==input) hide(); });
})();

// Category carousel
(function(){
  const track = $('#cat-track');
  CATEGORIES.forEach(c => {
    const a = document.createElement('a'); a.href = c.href; a.setAttribute('aria-label', c.name);
    a.innerHTML = `<img alt="${c.name}" src="${c.image}"><div class="card-body"><div class="card-title">${c.name}</div></div>`;
    track.appendChild(a);
  });
  $('#cat-next').addEventListener('click', ()=> track.scrollBy({left: track.clientWidth * .8, behavior: prefersReduced()?'auto':'smooth'}));
  $('#cat-prev').addEventListener('click', ()=> track.scrollBy({left: -track.clientWidth * .8, behavior: prefersReduced()?'auto':'smooth'}));
})();

// Products carousel
(function(){
  const track = $('#prod-track');
  PRODUCTS.slice(0,5).forEach(([n,c,p]) => {
    const el = document.createElement('article');
    const img = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=1200&auto=format&fit=crop';
    el.innerHTML = `<img alt="${n}" src="${img}"><div class="card-body"><div class="card-title">${n}</div><div class="muted small">${c}</div><div class="card-price">${currency(p)}</div></div>`;
    track.appendChild(el);
  });
  $('#prod-next').addEventListener('click', ()=> track.scrollBy({left: track.clientWidth * .8, behavior: prefersReduced()?'auto':'smooth'}));
  $('#prod-prev').addEventListener('click', ()=> track.scrollBy({left: -track.clientWidth * .8, behavior: prefersReduced()?'auto':'smooth'}));
})();

// Journal grid + Load more
(function(){
  const grid = $('#journal-grid');
  let shown = 0; const PAGE = 4;
  function render(){
    const next = ARTICLES.slice(shown, shown+PAGE);
    next.forEach(([t,a,d,s,img])=>{
      const card = document.createElement('article'); card.className='journal-card';
      card.innerHTML = `<img alt="${t}" src="${img}"><div class="meta"><p class="muted small">${a} • ${d}</p><h3>${t}</h3><p class="small">${s}</p><p><a class="button ghost small" href="#journal">Read More</a></p></div>`;
      grid.appendChild(card);
    });
    shown += next.length;
    const btn = $('#load-more');
    if(shown >= ARTICLES.length){ btn.disabled = true; btn.textContent = 'All articles loaded'; }
  }
  $('#load-more').addEventListener('click', render);
  render();
})();

// Welcome Popup (first visit)
(function(){
  const backdrop = $('#modal-backdrop');
  const modal = $('#welcome-modal');
  const form = $('#welcome-form');
  const closeBtn = $('#modal-close');
  const success = $('#welcome-success');
  const key = 'aetos_welcome_seen';

  function open(){ backdrop.classList.add('open'); modal.hidden = false; $('#first-name').focus(); trap(true); }
  function close(){ backdrop.classList.remove('open'); modal.hidden = true; trap(false); }

  function trap(enable){
    function handler(e){ if(e.key==='Escape') close(); }
    if(enable) document.addEventListener('keydown', handler); else document.removeEventListener('keydown', handler);
  }

  if(!localStorage.getItem(key)){
    setTimeout(open, 600);
  }

  closeBtn.addEventListener('click', close);
  backdrop.addEventListener('click', close);

  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    if(!String(data.email).includes('@')){ announce('Please enter a valid email'); return; }
    success.hidden = false; success.focus();
    localStorage.setItem(key,'1');
    setTimeout(close, 1200);
  });

  function announce(msg){
    const el = $('#welcome-error'); el.textContent = msg; el.hidden = false; setTimeout(()=> el.hidden = true, 2500);
  }
})();

// Footer newsletter
(function(){
  const f = $('#newsletter');
  const msg = $('#newsletter-msg');
  f.addEventListener('submit', (e)=>{
    e.preventDefault();
    const email = new FormData(f).get('email');
    if(!String(email).includes('@')){ msg.textContent = 'Please enter a valid email.'; msg.className='error'; return; }
    msg.textContent = 'Thanks for subscribing!'; msg.className='success'; f.reset();
  });
})();

// Helpers
function prefersReduced(){ return window.matchMedia('(prefers-reduced-motion: reduce)').matches; }
