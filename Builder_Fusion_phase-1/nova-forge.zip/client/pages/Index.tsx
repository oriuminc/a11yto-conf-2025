import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { Link } from "react-router-dom";
import { useState } from "react";
import { WelcomePopup } from "@/components/layout/WelcomePopup";

const categories = [
  {
    name: "The Vanguard Chronograph",
    description: "Sophisticated, multi-dial watches for precision timing.",
    image: "https://images.pexels.com/photos/33860151/pexels-photo-33860151.jpeg",
    href: "/watches/vanguard-chronograph",
  },
  {
    name: "The Sentinel Automatic",
    description: "Classic, self-winding timepieces with exhibition casebacks.",
    image: "https://images.pexels.com/photos/364822/rolex-watch-time-luxury-364822.jpeg",
    href: "/watches/sentinel-automatic",
  },
  {
    name: "The Shoreline Diver",
    description: "Robust, water-resistant watches built for adventure.",
    image: "https://images.pexels.com/photos/32968007/pexels-photo-32968007.jpeg",
    href: "/watches/shoreline-diver",
  },
  {
    name: "Premium Leather Straps",
    description: "Hand-stitched straps from Italian leather.",
    image: "https://images.pexels.com/photos/277390/pexels-photo-277390.jpeg",
    href: "/straps/leather",
  },
  {
    name: "Travel & Storage",
    description: "High-quality watch rolls and cases for protection.",
    image: "https://images.pexels.com/photos/32358659/pexels-photo-32358659.jpeg",
    href: "/accessories/travel-storage",
  },
];

const journalPosts = [
  {
    title: "Automatic vs. Quartz: A Guide",
    author: "Mark Jennings",
    date: "Aug 12, 2025",
    snippet: "Understanding the intricate mechanics of an automatic movement versus the precision of quartz. We break down what makes each one tick.",
    image: "https://images.unsplash.com/photo-1533139502658-0198f920d8e8?q=80&w=2940&auto=format&fit=crop",
  },
  {
    title: "How to Pair Your Watch and Strap",
    author: "Alisha Khan",
    date: "Aug 05, 2025",
    snippet: "A complete style guide to matching your timepiece with the perfect strap for any occasion, from the boardroom to the beach.",
    image: "https://images.unsplash.com/photo-1524805444758-089113d48a6d?q=80&w=2940&auto=format&fit=crop",
  },
  {
    title: "The Enduring Appeal of the Dive Watch",
    author: "Mark Jennings",
    date: "Jul 28, 2025",
    snippet: "From military history to modern icon, we explore why the dive watch remains one of the most popular styles in the world.",
    image: "https://images.unsplash.com/photo-1508057198894-247b23fe5ade?q=80&w=2940&auto=format&fit=crop",
  },
  {
    title: "A Look Inside Our Workshop",
    author: "David Chen",
    date: "Jul 21, 2025",
    snippet: "Go behind the scenes at AETOS and meet the people who design, assemble, and test every timepiece we create.",
    image: "https://images.unsplash.com/photo-1558017487-9531f21d7432?q=80&w=2940&auto=format&fit=crop",
  },
  {
    title: "Caring for Your Leather Strap",
    author: "Alisha Khan",
    date: "Jul 14, 2025",
    snippet: "Simple tips and tricks to clean, condition, and preserve your leather strap, ensuring it ages as gracefully as your watch.",
    image: "https://images.unsplash.com/photo-1562254293-9b3a5b6e6483?q=80&w=2940&auto=format&fit=crop",
  },
  {
    title: "What is Sapphire Crystal?",
    author: "Mark Jennings",
    date: "Jul 07, 2025",
    snippet: "We explain why we use sapphire crystal in all our watches and why it’s the gold standard for scratch resistance and clarity.",
    image: "https://images.unsplash.com/photo-1584385489563-a44f74a1a49c?q=80&w=2940&auto=format&fit=crop",
  },
  {
    title: "5 Iconic Watches in Cinema",
    author: "Liam Carter",
    date: "Jun 30, 2025",
    snippet: "From spies to astronauts, a look at the legendary timepieces that have shared the silver screen with Hollywood’s biggest stars.",
    image: "https://images.unsplash.com/photo-1522338140262-f4650c4737c2?q=80&w=2940&auto=format&fit=crop",
  },
  {
    title: "The AETOS Design Philosophy",
    author: "David Chen",
    date: "Jun 23, 2025",
    snippet: "Our founder discusses the principles of minimalism, function, and timelessness that guide every AETOS design.",
    image: "https://images.unsplash.com/photo-1542904543-f8633b3ae1e1?q=80&w=2940&auto=format&fit=crop",
  },
  {
    title: "A Brief History of the Chronograph",
    author: "Mark Jennings",
    date: "Jun 16, 2025",
    snippet: "Discover the fascinating history of the chronograph, from its origins in horse racing to its essential role in the space race.",
    image: "https://images.unsplash.com/photo-1539874754764-5a53e5333594?q=80&w=2940&auto=format&fit=crop",
  },
  {
    title: "Summer Style: The Best Watch Combos",
    author: "Alisha Khan",
    date: "Jun 09, 2025",
    snippet: "Lighten up your look for the warmer months with our top picks for watch and strap combinations that exude summer style.",
    image: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=2940&auto=format&fit=crop",
  },
  {
    title: "Why 316L Steel Matters",
    author: "Mark Jennings",
    date: "Jun 02, 2025",
    snippet: "Not all steel is created equal. Learn why we use surgical-grade 316L stainless steel for its superior corrosion resistance and durability.",
    image: "https://images.unsplash.com/photo-1617775326333-03f4f9a9a5b3?q=80&w=2940&auto=format&fit=crop",
  },
  {
    title: "Packing for Travel: The Watch Lover’s Guide",
    author: "Liam Carter",
    date: "May 26, 2025",
    snippet: "How to choose which watches to bring on your next trip and the best way to keep them safe and secure on the go.",
    image: "https://images.unsplash.com/photo-1506784983877-45594efa4c85?q=80&w=2940&auto=format&fit=crop",
  },
];

const products = [
  {
    name: "Vanguard Chrono - Midnight",
    category: "Vanguard Chronograph",
    price: 425,
    image: "https://images.pexels.com/photos/33871465/pexels-photo-33871465.jpeg",
    href: "/products/vanguard-chrono-midnight",
  },
  {
    name: "Vanguard Chrono - Sterling",
    category: "Vanguard Chronograph",
    price: 425,
    image: "https://images.pexels.com/photos/33871462/pexels-photo-33871462.jpeg",
    href: "/products/vanguard-chrono-sterling",
  },
  {
    name: "Vanguard Chrono - Navy Gold",
    category: "Vanguard Chronograph",
    price: 450,
    image: "https://images.pexels.com/photos/1010513/pexels-photo-1010513.jpeg",
    href: "/products/vanguard-chrono-navy-gold",
  },
  {
    name: "Sentinel 40 - Classic White",
    category: "Sentinel Automatic",
    price: 550,
    image: "https://images.pexels.com/photos/27553146/pexels-photo-27553146.jpeg",
    href: "/products/sentinel-40-classic-white",
  },
  {
    name: "Sentinel 40 - Onyx",
    category: "Sentinel Automatic",
    price: 550,
    image: "https://images.pexels.com/photos/8839887/pexels-photo-8839887.jpeg",
    href: "/products/sentinel-40-onyx",
  },
];

export default function Index() {
  const [visiblePosts, setVisiblePosts] = useState(4);

  const loadMorePosts = () => {
    setVisiblePosts((prev) => Math.min(prev + 4, journalPosts.length));
  };

  return (
    <>
      <WelcomePopup />
      {/* Hero Section */}
      <section className="relative h-[60vh] w-full bg-cover bg-center text-white"
        style={{ backgroundImage: "url('https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=2899&auto=format&fit=crop')" }}>
        <div className="absolute inset-0 bg-black/50" />
        <div className="relative z-10 flex h-full flex-col items-center justify-center text-center">
          <h1 className="text-5xl font-bold">Precision in Simplicity.</h1>
          <p className="mt-4 text-xl">Discover timepieces designed for the modern individual.</p>
          <Button asChild className="mt-8">
            <Link to="/watches">Shop The Collection</Link>
          </Button>
        </div>
      </section>

      {/* Featured Categories Carousel */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-center mb-8">Featured Categories</h2>
          <Carousel className="w-full">
            <CarouselContent>
              {categories.map((category) => (
                <CarouselItem key={category.name} className="md:basis-1/2 lg:basis-1/3">
                  <div className="p-1">
                    <Link to={category.href}>
                      <Card className="overflow-hidden">
                        <CardContent className="relative aspect-square p-0">
                          <img src={category.image} alt={category.name} className="object-cover w-full h-full" />
                          <div className="absolute inset-0 bg-black/40 flex items-end p-4">
                            <h3 className="text-white font-semibold text-lg">{category.name}</h3>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious />
            <CarouselNext />
          </Carousel>
        </div>
      </section>

      {/* Featured Products Carousel */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-secondary">
        <div className="container px-4 md:px-6">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-center mb-8">Featured Products</h2>
          <Carousel className="w-full">
            <CarouselContent>
              {products.map((product) => (
                <CarouselItem key={product.name} className="md:basis-1/2 lg:basis-1/3">
                  <div className="p-1">
                    <Link to={product.href}>
                      <Card className="overflow-hidden">
                        <CardContent className="relative aspect-[3/4] p-0">
                          <img src={product.image} alt={product.name} className="object-cover w-full h-full" />
                        </CardContent>
                      </Card>
                      <div className="mt-2 text-center">
                        <h3 className="font-semibold">{product.name}</h3>
                        <p className="text-muted-foreground">${product.price}</p>
                      </div>
                    </Link>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious />
            <CarouselNext />
          </Carousel>
        </div>
      </section>

      {/* Brand Statement */}
      <section className="bg-primary text-primary-foreground py-12 md:py-24 lg:py-32">
        <div className="container text-center">
          <h2 className="text-3xl font-bold">Engineered for Life.</h2>
          <p className="mt-4 max-w-2xl mx-auto">We use only the finest materials—from 316L stainless steel to sapphire crystal—to build watches that last a lifetime.</p>
          <Button asChild variant="secondary" className="mt-8">
            <Link to="/our-craftsmanship">Our Craftsmanship</Link>
          </Button>
        </div>
      </section>

      {/* Journal Snippets */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-center mb-8">From the Journal</h2>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {journalPosts.slice(0, visiblePosts).map((post) => (
              <Link to={`/journal/${post.title.toLowerCase().replace(/\s+/g, '-')}`} key={post.title}>
                <Card className="overflow-hidden">
                  <CardContent className="p-0">
                    <img src={post.image} alt={post.title} className="aspect-video object-cover" />
                    <div className="p-4">
                      <h3 className="font-semibold text-lg">{post.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">{post.author} &middot; {post.date}</p>
                      <p className="text-sm mt-2">{post.snippet}</p>
                      <span className="text-sm font-semibold mt-4 inline-block">Read More</span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
          {visiblePosts < journalPosts.length && (
            <div className="text-center mt-12">
              <Button onClick={loadMorePosts}>Load More</Button>
            </div>
          )}
        </div>
      </section>
    </>
  );
}
