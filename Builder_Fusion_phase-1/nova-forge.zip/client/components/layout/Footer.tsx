import { Link } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function Footer() {
  return (
    <footer className="bg-secondary text-secondary-foreground">
      <div className="container py-12">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          <div className="col-span-2 md:col-span-1">
            <h3 className="font-bold text-lg">AETOS</h3>
            <p className="mt-2 text-sm">Precision in Simplicity.</p>
          </div>
          <div>
            <h3 className="font-semibold">Shop</h3>
            <ul className="mt-4 space-y-2">
              <li><Link to="/watches" className="text-sm text-muted-foreground hover:text-foreground">Watches</Link></li>
              <li><Link to="/straps" className="text-sm text-muted-foreground hover:text-foreground">Straps</Link></li>
              <li><Link to="/accessories" className="text-sm text-muted-foreground hover:text-foreground">Accessories</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold">Support</h3>
            <ul className="mt-4 space-y-2">
              <li><Link to="/contact" className="text-sm text-muted-foreground hover:text-foreground">Contact</Link></li>
              <li><Link to="/faq" className="text-sm text-muted-foreground hover:text-foreground">FAQ</Link></li>
              <li><Link to="/shipping" className="text-sm text-muted-foreground hover:text-foreground">Shipping & Returns</Link></li>
            </ul>
          </div>
          <div className="col-span-2 md:col-span-1">
            <h3 className="font-semibold">Newsletter</h3>
            <p className="mt-4 text-sm">Join our mailing list for updates and offers.</p>
            <form className="mt-4 flex w-full max-w-sm items-center space-x-2">
                <Input type="email" placeholder="Email" />
                <Button type="submit">Subscribe</Button>
            </form>
          </div>
        </div>
        <div className="mt-8 border-t pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} AETOS Timepieces. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
