import { Link } from "react-router-dom";
import { Search, User, Heart, ShoppingCart, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
    Accordion,
    AccordionContent,
    AccordionItem,
    AccordionTrigger,
  } from "@/components/ui/accordion"
import { cn } from "@/lib/utils";
import React from "react";
import { PredictiveSearch } from "./PredictiveSearch";

const watchesMenu = [
  {
    title: "Shop All Watches",
    href: "/watches",
    description: "Browse our complete collection of timepieces.",
  },
  {
    title: "The Vanguard Chronograph",
    href: "/watches/vanguard-chronograph",
    description: "Sophisticated, multi-dial watches for precision timing.",
  },
  {
    title: "The Sentinel Automatic",
    href: "/watches/sentinel-automatic",
    description: "Classic, self-winding timepieces with exhibition casebacks.",
  },
  {
    title: "The Shoreline Diver",
    href: "/watches/shoreline-diver",
    description: "Robust, water-resistant watches built for adventure.",
  },
  {
    title: "The Minimalist 36",
    href: "/watches/minimalist-36",
    description: "A refined 36mm quartz watch.",
  },
  {
    title: "New Arrivals",
    href: "/watches/new-arrivals",
    description: "The latest additions to our collection.",
  },
];

const strapsMenu = [
    {
        title: "Shop All Straps",
        href: "/straps",
        description: "Discover our full range of watch straps.",
    },
    {
        title: "Leather Straps",
        href: "/straps/leather",
        description: "Hand-stitched straps from Italian leather.",
    },
    {
        title: "Steel Bracelets",
        href: "/straps/steel",
        description: "Durable and stylish stainless steel bracelets.",
    },
    {
        title: "Nylon Straps",
        href: "/straps/nylon",
        description: "Versatile and comfortable nylon straps.",
    },
];

const accessoriesMenu = [
    {
        title: "Shop All Accessories",
        href: "/accessories",
        description: "Complete your collection with our accessories.",
    },
    {
        title: "Watch Rolls & Cases",
        href: "/accessories/watch-rolls-cases",
        description: "Protect your timepieces in style.",
    },
    {
        title: "Strap Tools",
        href: "/accessories/strap-tools",
        description: "Tools to help you change your strap with ease.",
    },
];


export function Header() {
  const [open, setOpen] = React.useState(false);
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <div className="mr-4 hidden md:flex">
          <Link to="/" className="mr-6 flex items-center space-x-2">
            <span className="font-bold text-lg">AETOS</span>
          </Link>
          <NavigationMenu>
            <NavigationMenuList>
              <NavigationMenuItem>
                <NavigationMenuTrigger>Watches</NavigationMenuTrigger>
                <NavigationMenuContent>
                  <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px] ">
                    {watchesMenu.map((component) => (
                      <ListItem
                        key={component.title}
                        title={component.title}
                        href={component.href}
                      >
                        {component.description}
                      </ListItem>
                    ))}
                  </ul>
                </NavigationMenuContent>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <NavigationMenuTrigger>Straps</NavigationMenuTrigger>
                <NavigationMenuContent>
                  <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] lg:w-[600px] lg:grid-cols-2">
                     {strapsMenu.map((component) => (
                      <ListItem
                        key={component.title}
                        title={component.title}
                        href={component.href}
                      >
                        {component.description}
                      </ListItem>
                    ))}
                  </ul>
                </NavigationMenuContent>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <NavigationMenuTrigger>Accessories</NavigationMenuTrigger>
                <NavigationMenuContent>
                  <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] lg:w-[600px] lg:grid-cols-2">
                     {accessoriesMenu.map((component) => (
                      <ListItem
                        key={component.title}
                        title={component.title}
                        href={component.href}
                      >
                        {component.description}
                      </ListItem>
                    ))}
                  </ul>
                </NavigationMenuContent>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link to="/our-story" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                    Our Story
                  </NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link to="/journal" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                    Journal
                  </NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
            </NavigationMenuList>
          </NavigationMenu>
        </div>

        {/* Mobile Menu */}
        <div className="md:hidden">
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu />
              </Button>
            </SheetTrigger>
            <SheetContent side="left">
              <Link to="/" className="mb-4 flex items-center" onClick={() => setOpen(false)}>
                <span className="font-bold text-lg">AETOS</span>
              </Link>
              <div className="flex flex-col space-y-1">
                <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="item-1">
                        <AccordionTrigger>Watches</AccordionTrigger>
                        <AccordionContent>
                            <div className="flex flex-col space-y-2 pl-4">
                                {watchesMenu.map(item => (
                                    <Link key={item.href} to={item.href} onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground">{item.title}</Link>
                                ))}
                            </div>
                        </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-2">
                        <AccordionTrigger>Straps</AccordionTrigger>
                        <AccordionContent>
                            <div className="flex flex-col space-y-2 pl-4">
                                {strapsMenu.map(item => (
                                    <Link key={item.href} to={item.href} onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground">{item.title}</Link>
                                ))}
                            </div>
                        </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-3">
                        <AccordionTrigger>Accessories</AccordionTrigger>
                        <AccordionContent>
                            <div className="flex flex-col space-y-2 pl-4">
                                {accessoriesMenu.map(item => (
                                    <Link key={item.href} to={item.href} onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground">{item.title}</Link>
                                ))}
                            </div>
                        </AccordionContent>
                    </AccordionItem>
                </Accordion>
                <Link to="/our-story" onClick={() => setOpen(false)} className="py-4 font-medium">Our Story</Link>
                <Link to="/journal" onClick={() => setOpen(false)} className="py-4 font-medium">Journal</Link>
              </div>
            </SheetContent>
          </Sheet>
        </div>

        <div className="flex flex-1 items-center justify-end space-x-2">
          <PredictiveSearch />
          <nav className="flex items-center">
            <Link to="/account" className="p-2 hidden md:block">
              <User className="h-5 w-5" />
            </Link>
            <Link to="/wishlist" className="p-2 hidden md:block">
              <Heart className="h-5 w-5" />
            </Link>
            <Link to="/cart" className="p-2">
              <ShoppingCart className="h-5 w-5" />
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}

const ListItem = React.forwardRef<
  React.ElementRef<"a">,
  React.ComponentPropsWithoutRef<"a">
>(({ className, title, children, ...props }, ref) => {
  return (
    <li>
      <NavigationMenuLink asChild>
        <a
          ref={ref}
          className={cn(
            "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
            className
          )}
          {...props}
        >
          <div className="text-sm font-medium leading-none">{title}</div>
          <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
            {children}
          </p>
        </a>
      </NavigationMenuLink>
    </li>
  );
});
ListItem.displayName = "ListItem";
